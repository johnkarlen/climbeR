library(testthat)
library(climbeR)

test_check("climbeR")
