## Test environments

* local OS X install, R 4.1.0
* used check_win_devel()


## R CMD check results
There were no ERRORs or WARNINGs. 

There was 1 NOTE:

There were 2 notes:

* checking DESCRIPTION meta-information ... NOTE
Malformed Description field: should contain one or more complete sentences.

* checking R code for possible problems ... NOTE
calculateAMDMS: no visible binding for global variable ‘first_order’
