## ---- fig.show='hold'----------------------------------------------------
require(ranger)

## Classification forest with default settings
ranger(Species ~ ., data = iris)

## Prediction
train.idx <- sample(nrow(iris), 2/3 * nrow(iris))
iris.train <- iris[train.idx, ]
iris.test <- iris[-train.idx, ]
rg.iris <- ranger(Species ~ ., data = iris.train, write.forest = TRUE, importance = "impurity")
pred.iris <- predict(rg.iris, dat = iris.test)
table(iris.test$Species, pred.iris$predictions)

## ---- include=FALSE------------------------------------------------------
library(climbeR)

# call to climber function
result <- getAndPlotSOvsFO(rg.iris)
# ^ evaluated data ^
eval_data <- result$subtree_metrics
# second ord. vs first ord. plot
so_vs_fo <- result$plot

## ---- eval=FALSE---------------------------------------------------------
#  library(climbeR)
#  # call to climber function
#  result <- getAndPlotSOvsFO(rg.iris)
#  # evaluated data
#  eval_data <- result$subtree_metrics
#  # second ord. vs first ord. plot
#  so_vs_fo <- result$plot

## ---- fig.width=6, fig.height=6------------------------------------------
# let's take a look
plot(so_vs_fo)

## ------------------------------------------------------------------------
knitr::kable(rg.iris$variable.importance)

## ---- results='asis'-----------------------------------------------------
# another look at the result 
knitr::kable(eval_data)

